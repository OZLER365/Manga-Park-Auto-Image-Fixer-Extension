
(() => {
  const processed = new WeakSet();
  const servers = ["00", "01", "03", "04"];
  const serverRegex = /^https:\/\/s\d{2}/;

  function fixImage(img) {
    if (processed.has(img) || !img.src || !serverRegex.test(img.src)) return;
    processed.add(img);

    const path = img.src.replace(serverRegex, "");
    let index = 0;

    img.onerror = () => {
      if (index < servers.length) {
        img.src = `https://s${servers[index++]}${path}`;
      }
    };

    img.src = `https://s${servers[0]}${path}`;
  }

  function scan(root = document) {
    const images = root.getElementsByTagName("img");
    for (let i = 0; i < images.length; i++) {
      if (!images[i].complete || !images[i].naturalWidth) {
        fixImage(images[i]);
      }
    }
  }

  scan();

  new MutationObserver(mutations => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.tagName === "IMG") {
          fixImage(node);
        } else if (node.querySelectorAll) {
          scan(node);
        }
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
